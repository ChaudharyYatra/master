</div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <!--<b>Version</b> 3.2.0-->
    </div>
    <center><strong>Copyright &copy; <?php echo date("Y"); ?>.</strong> All rights reserved.</center>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->


<!-- jQuery -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-validation/additional-methods.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/summernote/summernote-bs4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/codemirror.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/css/css.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/xml/xml.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/htmlmixed/htmlmixed.js"></script>

<script src="<?php echo base_url(); ?>assets/admin/plugins/select2/js/select2.full.min.js"></script>
<!-- Bootstrap4 Duallistbox -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/inputmask/jquery.inputmask.min.js"></script>
<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap color picker -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Bootstrap Switch -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<!-- BS-Stepper -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bs-stepper/js/bs-stepper.min.js"></script>
<!-- dropzonejs -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/dropzone/min/dropzone.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>assets/admin/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url(); ?>assets/admin/dist/js/demo.js"></script>

<!-- Page specific script -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/select2/js/select2.full.min.js"></script>

<!-- Summernote -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/summernote/summernote-bs4.min.js"></script>
<!-- CodeMirror -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/codemirror.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/css/css.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/xml/xml.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/htmlmixed/htmlmixed.js"></script>


<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap color picker -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Bootstrap Switch -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<!-- BS-Stepper -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bs-stepper/js/bs-stepper.min.js"></script>
<!-- dropzonejs -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/dropzone/min/dropzone.min.js"></script>



<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/inputmask/jquery.inputmask.min.js"></script>

<!-- DataTables  & Plugins -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jszip/jszip.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>



<script>  
 $(document).ready(function(){  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '1'; 
           //alert(email);
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/check_notification_count",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                        //  console.log(responce);
                        //  console.log('jjjjjjjjjjjjjjjjjjjj');
                         if(responce > 0)
                         {
                            $('#notification_count').append('<i class="fas fa-envelope mr-2"></i> '+responce+' Domestic Packages');
                            // $('#btn_agent').prop('disabled', true)
                             
                         }else
                         {
                             $('#notification_count').html('');
                            //  $('#btn_agent').prop('disabled', false)
                         } 
                     }  
                });  
           }  
      });  
 </script>

<script>  
 $(document).ready(function(){
  $("#notification_count").click(function() {  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '0'; 
           //alert(email);
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/enquiry_view",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                         if(responce = true)
                         {
                              // alert(responce);
                          // redirect($this->module_url_path.'agent/booking_enquiry/index');
                         }
                     }  
                });  
           } 
          }); 
      });  
 </script>


<script>  
 $(document).ready(function(){  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '1'; 
           //alert(email);
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/check_international_count",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                         if(responce > 0)
                         { 
                            $('#international_count').append('<i class="fas fa-users mr-2"></i> '+responce+' International Packages');
                            // $('#btn_agent').prop('disabled', true)
                             
                         }else
                         {
                             $('#international_count').html('');
                            //  $('#btn_agent').prop('disabled', false)
                         } 
                     }  
                });  
           }  
      });  
 </script>

<script>  
 $(document).ready(function(){
  $("#international_count").click(function() {  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '1'; 
           //alert(email);
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/international_view",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                         if(responce = true)
                         {
                          // redirect($this->module_url_path.'agent/booking_enquiry/index');
                          window.location.href = "<?=base_url()?>agent/international_booking_enquiry/index";
                         }
                     }  
                });  
           } 
          }); 
      });  
 </script>

<script>
//   $(document).ready(function() { 
//            var send_qty = $('.send_qty').val(); 
//            console.log(send_qty);
     
//      $('.cancel_status').hide();
// }); 

$(".send_qty").each(function () {                
    var send_qty = $(this).val(); 
//     alert(send_qty);  
     if(send_qty!='')
     {
          $('.cancel_status').hide();
          $('#submit').attr("disabled", true);
     }
     else{
          $('.cancel_status').show();
          $('#submit').attr("disabled", false);
     }
 });

</script>


<script>
  $(document).ready(function(){ 
  $('#not_in_stock').click(function(){ 
  $('input[name="send_qty[]"]').val('Not in stock');
   });
});
</script>

<!-- without enter sending qu -->
<script>
$('.sendButton').attr("disabled", true);

$('.send_qty').on('change', function() {

$(".send_qty").each(function () {                
    var s_send = $(this).val(); 
    
     if(send_qty!='')
     {
          $('.sendButton').attr("disabled", false);
     }
     else{
          $('.sendButton').attr("disabled", true);
     }
 });
});
</script>

<!-- using ajax submit send qty then open modal -->
<script>


  $("#submit").click(function() { 
     var new_array_qty = [];
     var new_array_sod = [];
     var o_id =  $(".order_id").val();

     $(".send_qty").each(function () 
     {                
          var s_send = $(this).val();
          new_array_qty.push($(this).val()) 
     });

     $(".stationary_order_id").each(function () 
     {  
          var so_id =  $(this).val();
          new_array_sod.push($(this).val())
               
     });

     $("#od_id").val(new_array_sod);
 //alert(new_array_sod);
     if(new_array_qty!='')
     {
          $.ajax({
                          type: "POST",
                          url:'<?=base_url()?>stationary/stationary_request/send',
                          data: {s_send: new_array_qty,
                              so_id: new_array_sod,
                              o_id: o_id
                           },
                         //  dataType: 'json',
                         //  cache: false,
                          success: function(response) {
                              console.log(response);
                               if (response= true) {
                                  alert('success');
                                  $('#exampleModal_send').modal('show'); 
                              } else {
                                  alert('error');

                              }
                          },
                          
                      });
     }
     // else{
     //      $('.sendButton').attr("disabled", true);
     // }
}); 

</script>

<!-- $("#submit").click(function() { 
     
     $(".send_qty").each(function (){
     var send_qty = $(this).val(); 
     // alert(send_qty); 
     $.ajax({
                          type: "POST",
                          url:'<//?=base_url()?>Stationary_request/send',
                          data: {submit: submit,
                              send_qty: send_qty[],
                         //    'send_qty'   =>    $_POST["send_qty"][$i] 
                          }
                         })
}); 
});   -->
