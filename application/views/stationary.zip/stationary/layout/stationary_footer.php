



</div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
 

    <div class="float-right d-none d-sm-block">
      <!--<b>Version</b> 3.2.0-->
    </div>
    <center><strong>Copyright &copy; <?php echo date("Y"); ?>.</strong> All rights reserved.</center>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->


<!-- jQuery -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jquery-validation/additional-methods.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/summernote/summernote-bs4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/codemirror.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/css/css.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/xml/xml.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/htmlmixed/htmlmixed.js"></script>

<script src="<?php echo base_url(); ?>assets/admin/plugins/select2/js/select2.full.min.js"></script>
<!-- Bootstrap4 Duallistbox -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/inputmask/jquery.inputmask.min.js"></script>
<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap color picker -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Bootstrap Switch -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<!-- BS-Stepper -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bs-stepper/js/bs-stepper.min.js"></script>
<!-- dropzonejs -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/dropzone/min/dropzone.min.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>assets/admin/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?php echo base_url(); ?>assets/admin/dist/js/demo.js"></script>

<!-- Page specific script -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/select2/js/select2.full.min.js"></script>

<!-- Summernote -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/summernote/summernote-bs4.min.js"></script>
<!-- CodeMirror -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/codemirror.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/css/css.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/xml/xml.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/codemirror/mode/htmlmixed/htmlmixed.js"></script>


<!-- date-range-picker -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap color picker -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-colorpicker/js/bootstrap-colorpicker.min.js"></script>
<!-- Tempusdominus Bootstrap 4 -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>
<!-- Bootstrap Switch -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<!-- BS-Stepper -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/bs-stepper/js/bs-stepper.min.js"></script>
<!-- dropzonejs -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/dropzone/min/dropzone.min.js"></script>



<script src="<?php echo base_url(); ?>assets/admin/plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/moment/moment.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/inputmask/jquery.inputmask.min.js"></script>

<!-- DataTables  & Plugins -->
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/jszip/jszip.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/pdfmake/pdfmake.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/pdfmake/vfs_fonts.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/plugins/datatables-buttons/js/buttons.colVis.min.js"></script>

<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "csv", "excel", "pdf", "print", "colvis"]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>



<script>  
 $(document).ready(function(){  
	 

	 
	 
 // var email = $('#agent_sess_id').val();  
           var agent_id = '1'; 
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/check_notification_count",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                        //  console.log(responce);
                        //  console.log('jjjjjjjjjjjjjjjjjjjj');
                         if(responce > 0)
                         {
                            $('#notification_count').append('<i class="fas fa-envelope mr-2"></i> '+responce+' Domestic Packages');
                          
                             
                         }else
                         {
                             $('#notification_count').html('');
                           
                         } 
                     }  
                });  
           }  
      });  
 </script>

<script>  
 $(document).ready(function(){
  $("#notification_count").click(function() {  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '0'; 
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/enquiry_view",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                         if(responce = true)
                         {
                              // (responce);
                          // redirect($this->module_url_path.'agent/booking_enquiry/index');
                         }
                     }  
                });  
           } 
          }); 
      });  
 </script>


<script>  
 $(document).ready(function(){  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '1'; 
           //(email);
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/check_international_count",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                         if(responce > 0)
                         { 
                            $('#international_count').append('<i class="fas fa-users mr-2"></i> '+responce+' International Packages');
                          
                             
                         }else
                         {
                             $('#international_count').html('');
                           
                         } 
                     }  
                });  
           }  
      });  
 </script>

<script>  
 $(document).ready(function(){
  $("#international_count").click(function() {  
 // var email = $('#agent_sess_id').val();  
           var agent_id = '1'; 
           //(email);
           if(agent_id != '')  
           {  
                $.ajax({  
                     url:"<?php echo base_url(); ?>agent/dashboard/international_view",  
                     method:"POST",  
                     data:{agent_id:agent_id},  
                     success:function(responce){ 
                         if(responce = true)
                         {
                          // redirect($this->module_url_path.'agent/booking_enquiry/index');
                          window.location.href = "<?=base_url()?>agent/international_booking_enquiry/index";
                         }
                     }  
                });  
           } 
          }); 
      });  
 </script>




<script>
  $(document).ready(function(){ 
  $('#not_in_stock').click(function(){ 
  $('input[name="send_qty[]"]').val('Not in stock');
   });
});
</script>

<!-- without enter sending qu -->
<script>
	
	 $(document).ready(function(){ 
		 var ostatus = $('#stationary_order_status').val(); 
            $('.sendButton').attr("disabled", true);
		 if(ostatus=='yes'){
			
			$('.send').attr("disabled", true);
		 }
		 
$('.send_qty').on('keyup', function() {

     var p=$(this).val(); 
     // console.log(p); 
     var currentRow=$(this).closest("tr"); 
     var col3=currentRow.find("td:eq(2)").text(); 
     console.log(parseInt(col3));
     if(parseInt(p) <= parseInt(col3) && p >0)
     {
$(".send_qty").each(function () {  
     
     var currentRow1=$(this).closest("tr"); 
     var col31=currentRow1.find("td:eq(2)").text(); 
     // var colid31=currentRow1.find("td:eq(4)").attr('id'); 
     console.log(parseInt(col3));

    var s_send = $(this).val(); 

    var s_send_disabled = $(this).attr('disabled'); 
     if((s_send!='' && s_send>0 && col31>=s_send))
     {
          $('.sendButton').attr("disabled", false);
     }
     else if(s_send='' && s_send_disabled!='' && s_send_disabled=='disabled'){

          $('.sendButton').attr("disabled", false);
     }
     else if(s_send!='' && s_send==0){
          $('.sendButton').attr("disabled", true);
          return false;
     }
     else if(s_send==''){
          $('.sendButton').attr("disabled", true);
          return false;
     }else if((s_send!='' && s_send>0 && col31<s_send))
     {
          $('.sendButton').attr("disabled", true);
     }
     });
}else{
     $('.sendButton').attr("disabled", true);
     alert('Please insert less quantity or equal quantity');
}
});
	 });	 
</script>


<script>
     $(document).on("change","select",function(){
         var selectedOption=$(this).val();
           var select_name=$(this).attr('name');
           var select_id=$(this).attr('id');

          $('.from_series').find('option[value="' + selectedOption + '"]').prop('disabled', true);

          $('#'+select_id).find('option[value="' + selectedOption + '"]').prop('disabled', false);

          $(".from_series").each(function () {
               var from_series_id=$(this).val();
               if(from_series_id!="")
               {
                   
          $('.save_series').attr("disabled", false);
               }else{
          $('.save_series').attr("disabled", true);
                   
               }
          });

     });
</script>


<!-- using ajax submit send qty then open modal -->
<script>


  $("#submit").click(function(event) { 
     var new_array_qty = [];
     var new_array_sod = [];
     var status_array = [];
     var o_id =  $(".order_id").val();
     var send_status='';

     $(".send_qty").each(function () 
     {                
          var s_send = $(this).val();
          var send_status = $(this).attr('status');
          
          if(s_send==0)
          {
               $('.sendButton').attr("disabled", true);
               // event.preventDefault();
          }
          new_array_qty.push($(this).val()); 
          status_array.push($(this).attr('status')); 
     });

     $(".stationary_order_id").each(function () 
     {  
          var so_id =  $(this).val();
          new_array_sod.push($(this).val())
               
     });

     $("#od_id").val(new_array_sod);
     if(new_array_qty!='')
     {

          // console.log($.isEmptyObject(new_array_qty));

          $.ajax({
                          type: "POST",
                          url:'<?=base_url()?>stationary/stationary_request/send',
                          data: {s_send: new_array_qty,
                              so_id: new_array_sod,
                              o_id: o_id,
                              send_status:status_array
                           },
                         //  dataType: 'json',
                         //  cache: false,
                          success: function(response) {
                           
                              console.log(response);
                               if (response== 'true') {
                                  $('#exampleModal_send').modal('show'); 
                              } else if (response== 'rejected') {
                                   window.location.href = "<?=base_url()?>stationary/stationary_request/index";
                              }else{
                                  alert('error');

                              }
                          },
                          
                      });
     }
    
}); 

</script>

<!-- new code stationary as per client changes -->

<script>


	
	
    $('.send_qty').keyup(function(){
        var count = $(this).val();
        var attrval =$(this).attr('attr-series_yes_no');
        var attrval_stid =$(this).attr('attr_stid');
		var modal_id =$(this).attr('attr-modal-id');
		var append_id='series_yes'+modal_id;
        

      if(attrval =="Yes"){ 

        $.ajax({
        url:'<?=base_url()?>stationary/stationary_request/get_series', 
        method: 'post',
        data: {stationary_id: attrval_stid},
        dataType: 'json',
        success: function(response){
        console.log(response);
        
			var remove_tr_id='detail_tr'+modal_id;
          $('.'+remove_tr_id).remove(); 
	// var id_for_update_series = '0'+modal_id;
	var id_for_update_series = modal_id;
            for(var i=0; i<count; i++){
            var add_id=i+modal_id;
             var add_id_name=modal_id;
				// var add_id=parseInt(i)+parseInt(1);
        var structure = $(` 

               <tr class="`+remove_tr_id+`"+>
                  <td>
                    <select class="form-control ayear" style="width: 100%;" name="academic_year`+add_id_name+`[]" id="academic_year`+id_for_update_series+`" required="required">
                      <option value="">Select year</option>
                      <?php
                          foreach($academic_years_data as $academic_years_info) 
                          { 
                      ?>
                          <option value="<?php echo $academic_years_info['id']; ?>"><?php echo $academic_years_info['year']; ?></option>
                      <?php } ?>
                    </select>
                  </td>
                  <td>
                    <select class="form-control from_series" style="width: 100%;" name="from_series`+add_id_name+`[]" id="series_data`+add_id+`" required="required"
                    attr_row_count="`+add_id+`">
                        <option value="">Select series</option>
                       
                    </select>
                  </td>
                  <td>
            <input type="text" class="form-control remark" name="remark`+add_id_name+`[]" value="" id="remark`+add_id+`" placeholder="Remark"/>

                  </td>
               </tr>
                                   

               `);
        
         
            $('#'+append_id).append(structure); 
            $('.save_series').attr("disabled", true);

            var sid='series_data'+add_id;                
            $('#'+sid).find('option').not(':first').remove();
       
          $.each(response,function(index,data){             
             $('#'+sid).append('<option value="'+data['id']+'">'+data['from_series']+'-'+data['to_series']+'</option>');
          });
          
        }

      }
     }); 
     }
     
       
    });

</script>

<script>

//   $(document).ready(function(){
//     var col3=0;
//     $('.send').on('click', function() {
//       // var currentRow=$(this).closest("tr"); 
//       var currentRow=$(this).closest("tr"); 
//       var col3=currentRow.find('input[name="send_qty[]"]').val();
//     });
//  for(var i=1; i<=col3;i++)
//  {
//   console.log(i);
//   var abc='series_data'+i;
//   $('#'+abc).on('change', function () {
//     var did = $(this).val();
//   });
// }
// });
 </script>  


<script>
     $(document).ready(function(){

          $(document).on("click","button",function(){
               var main_id=$(this).attr('attr-modal-id');
               var main_name=$(this).attr('name');
               var id=$(this).attr('id');
               if(main_name=='save_series'){

			var order_id = $('#order_id').val();
        	     var order_d_id = main_id;
        	     var form_type = $('#form_type').val();
               var save_series='save_series';
			  
			var from_series='from_series'+main_id+'[]';
			var from_series = $('select[name="'+from_series+'"]').map(function () {
                    return this.value;
               }).get();

               //var from_count=from_series.length;
               
               // 
             
		    

			var academic_year='academic_year'+main_id+'[]';
               var academic_year = $('select[name="'+academic_year+'"]').map(function () {
                    return this.value; // $(this).val()
               }).get();

			var remark='remark'+main_id+'[]';
               var remark = $('input[name="'+remark+'"]').map(function () {
                    return this.value; // $(this).val()
               }).get();

               $.ajax({
                         method: 'post',
                         url:'<?=base_url()?>stationary/stationary_request/save_details',
                         data: {order_id: order_id,
                            order_d_id: order_d_id,
                            form_type: form_type,
                            academic_year: academic_year,
                            remark: remark,
                            save_series:save_series,
                            from_series:from_series
                         },
                         dataType: 'json',
                         cache: false,
                         success: function(response) {
                              if (response=true) {
                                   alert('success');
                                
                              } else {
                                  alert('error');

                              }
                         },
                          
                    });



               }else if(main_name=='reject_send'){
                    var main_reject_id=$(this).attr('attr-modal-reject-id');
                    var fill_id_for_hide=$(this).attr('fill_id');

                    var o_id = $('#o_id').val();
               
        	     var o_d_id = main_reject_id;
			  
			var reject_comment='reject_comment'+main_reject_id;
			var reject_comment = $('input[name="'+reject_comment+'"]').map(function () {
                    return this.value; // $(this).val()
               }).get();

              
		    var single_reject_comment= reject_comment[0];

               $.ajax({
                         method: 'post',
                         url:'<?=base_url()?>stationary/stationary_request/reject',
                         data: {o_id: o_id,
                                o_d_id: o_d_id,
                                reject_comment: single_reject_comment
                         },
                         dataType: 'json',
                         cache: false,
                         success: function(response) {
                              if (response=true) {
                                   alert('Rejected Successfully');

                            $('#'+fill_id_for_hide).prop('disabled', true);
                            $('[attr-modal-id="'+main_reject_id+'"]').attr('disabled','disabled');
                            $('[attr-modal-id="'+main_reject_id+'"]').attr('status','rejected');

                            $(".send_qty").each(function () {                
    var s_send = $(this).val(); 
    var s_send_disabled = $(this).attr('disabled'); 
    if((s_send!=''))
     {
          $('.sendButton').attr("disabled", false);
     }
     else if(s_send=='' && s_send_disabled!='' && s_send_disabled=='disabled'){

          $('.sendButton').attr("disabled", false);
     }
     else if(s_send==''){

          $('.sendButton').attr("disabled", true);
     }
     });

                              } else {
                                  alert('error');

                              }
                         },
                          
                    });
               }

          });
	});
</script>
