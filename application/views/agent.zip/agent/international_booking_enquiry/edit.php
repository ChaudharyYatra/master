<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo $module_title; ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <a href="<?php echo $module_url_path; ?>/index"><button class="btn btn-primary">List</button></a>
              
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <?php $this->load->view('agent/layout/agent_alert'); ?>
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title"><?php echo $page_title; ?></h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <?php
                   foreach($arr_data as $info) 
                   { 
                     ?>
              <form method="post" enctype="multipart/form-data">
                <div class="card-body">
                <div class="row">
                        <div class="col-md-6">
                              <div class="form-group">
                                <label>First name</label>
                                <input type="text" class="form-control" name="first_name" id="first_name" placeholder="Enter First Name" minlength="10" maxlength="10" value="<?php echo $info['first_name']; ?>" required="required">
                              </div>
                        </div>
                        <div class="col-md-6">
                                <div class="form-group">
                                    <label>Last name</label>
                                    <input type="text" class="form-control" name="last_name" id="last_name" placeholder="Enter Last Name" value="<?php echo $info['last_name']; ?>" required="required">
                                </div>
                        </div>
                        <div class="col-md-6">
                                <div class="form-group">
                                    <label>Mobile number</label>
                                    <input type="text" class="form-control" name="mobile_number" id="mobile_number" placeholder="Enter Mobile Number" value="<?php echo $info['mobile_number']; ?>" required="required">
                                </div>
                        </div>
                        <div class="col-md-6">
                                <div class="form-group">
                                    <label>Email address</label>
                                    <input type="text" class="form-control" name="email_address" id="email_address" placeholder="Enter Email Address" value="<?php echo $info['email']; ?>" required="required">
                                </div>
                        </div>
                        <div class="col-md-6">
                                <div class="form-group">
                                    <label>Gender </label> <br>
                                    &nbsp;&nbsp;<input type="radio" name="gender" id="gender" value="Male" <?php if(isset($info['gender'])){if($info['gender']=='Male') {echo'checked';}}?> required="required">&nbsp;&nbsp;Male
                                    &nbsp;&nbsp;<input type="radio" name="gender" id="gender" value="Female" <?php if(isset($info['gender'])){if($info['gender']=='Female') {echo'checked';}}?> required="required">&nbsp;&nbsp;Female
                                </div>
                        </div>
                        <!-- <div class="col-md-6">
                                <div class="form-group">
                                    <label>Tour number</label>
                                    <input type="text" class="form-control" name="tour_number" id="tour_number" placeholder="Enter Tour Number" value="<?php echo $info['package_id']; ?>" required="required">
                                </div>
                        </div> -->
                        <div class="col-md-6">
                                <div class="form-group">
                                    <label>Tour number</label>
                                    <select class="form-control" name="packages" id="packages" onfocus='this.size=6;' onblur='this.size=1;' 
                                            onchange='this.size=1; this.blur();'>
                                        <option value="">Select tour Number</option>
                                        <?php foreach($international_packages_data as $international_packages_data_value){ ?> 
                                            <option value="<?php echo $international_packages_data_value['tour_number'];?>" <?php if(isset($info['package_id'])){if($international_packages_data_value['tour_number'] == $info['package_id']) {echo 'selected';}}?> ><?php echo $international_packages_data_value['tour_number'];?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                        </div>

                        <div class="col-md-6">
                              <div class="form-group">
                                <label>Coming from</label>
                                  <select class="form-control niceSelect" name="coming_form" id="coming_form" onfocus='this.size=3;' onblur='this.size=1;' 
                                        onchange='this.size=1; this.blur();' required="required">
                                      <option value="">Select coming from</option>
                                      <option value="Walking" <?php if(isset($info['fld_coming_from'])){if("Walking" == $info['fld_coming_from']) {echo 'selected';}}?> >Walking</option> 
                                      <option value="Calling" <?php if(isset($info['fld_coming_from'])){if("Calling" == $info['fld_coming_from']) {echo 'selected';}}?> >Calling</option> 
                                      <option value="Facebook" <?php if(isset($info['fld_coming_from'])){if("Facebook" == $info['fld_coming_from']) {echo 'selected';}}?> >Facebook</option>  
                                      <option value="Instagram" <?php if(isset($info['fld_coming_from'])){if("Instagram" == $info['fld_coming_from']) {echo 'selected';}}?> >Instagram</option> 
                                      <option value="Youtube" <?php if(isset($info['fld_coming_from'])){if("Youtube" == $info['fld_coming_from']) {echo 'selected';}}?> >Youtube</option> 
                                  </select>
                              </div>
                        </div>

                </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary" name="submit" value="submit">Submit</button>
					<a href="<?php echo $module_url_path; ?>/index"><button type="button" class="btn btn-danger" data-bs-dismiss="modal">Cancel</button></a>
                </div>
              </form>
              <?php } ?>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  

</body>
</html>
