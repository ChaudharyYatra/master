<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1><?php echo $module_title; ?></h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <a href="<?php echo $module_url_path; ?>/index"><button class="btn btn-primary">List</button></a>
              
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- jquery validation -->
            <?php $this->load->view('agent/layout/agent_alert'); ?>
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title"><?php echo $page_title; ?></h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form method="post" enctype="multipart/form-data">
                <div class="card-body">
                 <div class="row">
                      <div class="col-md-6">
                              <div class="form-group">
                                <label>First name</label>
                                <input type="text" class="form-control" name="first_name" id="first_name" placeholder="Enter First Name" required="required">
                              </div>
                      </div>
                      <div class="col-md-6">
                              <div class="form-group">
                                <label>Last name</label>
                                <input type="text" class="form-control" name="last_name" id="last_name" placeholder="Enter Last Name" required="required">
                              </div>
                      </div>
                      <div class="col-md-6">
                              <div class="form-group">
                                <label>Mobile number</label>
                                <input type="text" class="form-control" name="mobile_number" id="mobile_number" placeholder="Enter Mobile Number" minlength="10" maxlength="10" required="required">
                              </div>
                      </div>
                      <div class="col-md-6">
                              <div class="form-group">
                                <label>Email address</label>
                                <input type="text" class="form-control" name="email_address" id="email_address" placeholder="Enter Email Address" required="required">
                              </div>
                      </div>
                      <div class="col-md-6">
                              <div class="form-group">
                                <label>Gender </label> <br>
                                &nbsp;&nbsp;<input type="radio" name="gender" id="gender" value="Male" required="required">&nbsp;&nbsp;Male
                                &nbsp;&nbsp;<input type="radio" name="gender" id="gender" value="Female" required="required">&nbsp;&nbsp;Female
                              </div>
                      </div>
                      <!-- <div class="col-md-6">
                              <div class="form-group">
                                <label>Tour number</label>
                                <input type="text" class="form-control" name="tour_number" id="tour_number" placeholder="Enter Tour Number" required="required">
                              </div>
                      </div> -->
                      <div class="col-md-6">
                              <div class="form-group">
                                <label>Tour number</label>
                                  <select class="form-control" name="packages" id="packages" onfocus='this.size=6;' onblur='this.size=1;' 
                                        onchange='this.size=1; this.blur();'>
                                    <option value="">Select tour title</option>
                                    <?php foreach($international_packages_data as $international_packages_data_value){ ?> 
                                        <option value="<?php echo $international_packages_data_value['tour_number'];?>"><?php echo $international_packages_data_value['tour_number'];?></option>
                                    <?php } ?>
                                  </select>
                              </div>
                      </div>

                      <div class="col-md-6">
                              <div class="form-group">
                                <label>Coming from</label>
                                  <select class="form-control niceSelect" name="coming_form" id="coming_form" onfocus='this.size=3;' onblur='this.size=1;' 
                                        onchange='this.size=1; this.blur();' required="required">
                                      <option value="">Select coming from</option>
                                      <option value="Walking">Walking</option> 
                                      <option value="Calling">Calling</option> 
                                      <option value="Facebook">Facebook</option>  
                                      <option value="Instagram">Instagram</option> 
                                      <option value="Youtube">Youtube</option> 
                                  </select>
                              </div>
                      </div>
                     
              </div>
                <!-- /.card-body -->
                <div class="card-footer">
                  <button type="submit" class="btn btn-primary" name="submit" value="submit">Submit</button> 
                  <a href="<?php echo $module_url_path; ?>/index"><button type="button" class="btn btn-danger" >Cancel</button></a>
                </div>
					
              </form>
            </div>
            <!-- /.card -->
            </div>
          <!--/.col (left) -->
          <!-- right column -->
          <div class="col-md-6">

          </div>
          <!--/.col (right) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  

</body>
</html>
