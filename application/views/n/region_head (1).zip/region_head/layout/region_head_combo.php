<?php	
	$this->load->view("region_head/layout/region_head_header");
 	$this->load->view("region_head/layout/region_head_sidebar");
 	$this->load->view("region_head/".$middle_content);
	 $this->load->view("region_head/layout/region_head_footer");
?>