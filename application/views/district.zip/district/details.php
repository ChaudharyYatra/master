<div class="main-container">
			<div class="pd-ltr-20 xs-pd-20-10">
				<div class="min-height-200px">

                    <!-- Export Datatable start -->
					<?php $this->load->view('admin/layout/admin_alert'); ?>
					
					<div class="card-box mb-30">
						<div class="pd-20">
							<h4 class="text-blue h4"><?php echo $page_title; ?></h4>
						</div>
						<div class="pb-20">
						<div class="card-body">

							<?php  foreach($arr_data as $info) 
                            { ?>

							<div class="card-body">
                                <table id="example2" class="table table-bordered table-hover">
                                <tr>
                                    <th>District English</th>
                                    <td><?php echo $info['district_english']; ?></td>

                                    <th>District Marathi</th>
                                    <td><?php echo $info['district_marathi']; ?></td>
                                </tr>
                                
                                </table>
								<div class="col-md-4">
                                <a href="<?php echo $module_url_path; ?>/index"><button type="button" class="btn btn-danger">Cancel</button></a>
                            </div>
                            </div>
							<?php } 
							 ?>
						</div>
					</div>