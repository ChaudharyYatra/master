<div class="main-container">
	<div class="pd-ltr-20 xs-pd-20-10">
		<div class="min-height-200px">

            <!-- Export Datatable start -->
            <?php $this->load->view('admin/layout/admin_alert'); ?>
            
            <div class="card-box mb-30">
                <div class="pd-20">
                    <h4 class="text-blue h4"><?php echo $page_title; ?></h4>
                </div>
                <div class="">
                    <div class="card-body">
                    <form method="post" enctype="multipart/form-data" id="district_1">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>District English</label>
                                    <input class="form-control" type="text" placeholder="District English" name="district_english" oninput="this.value = this.value.replace(/[^a-zA-Z ]/g, '').replace(/(\..*)\./g, '$1');">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>District Marathi</label>
                                    <input class="form-control" type="text" placeholder="District Marathi" name="district_marathi">
                                </div>
                            </div>
                            <div class="col-md-4">
                                <button type="submit" class="btn btn-success" name="submit" value="submit">Submit</button>
                                <a href="<?php echo $module_url_path; ?>/index"><button type="button" class="btn btn-danger">Cancel</button></a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>