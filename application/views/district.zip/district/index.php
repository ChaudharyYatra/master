<div class="main-container">
			<div class="pd-ltr-20 xs-pd-20-10">
				<div class="min-height-200px">

                    <!-- Export Datatable start -->
					<?php $this->load->view('admin/layout/admin_alert'); ?>
					
					<div class="card-box mb-30">
						<div class="pd-20">
							<!-- <h4 class="text-blue h4"><?php //echo $page_title; ?></h4> -->
							<div class="container">
								<div class="row">
									<div class="col-sm-6 mt-3">
										<h2><?php echo $page_title; ?></h2>
									</div>
									<div class="col-sm-6">
										<ol class="breadcrumb float-sm-right">
										<a href="<?php echo $module_url_path; ?>/add"><button class="btn btn-success">Add</button></a>
										
										</ol>
									</div>
									</div>
								
							</div>
						</div>
						<div class="pb-20">
						<div class="card-body">
							<?php  if(count($arr_data) > 0 ) 
						{ ?>
							<table
								class="table hover multiple-select-row data-table-export nowrap">
								<thead>
									<tr>
										<th class="table-plus datatable-nosort">Sr no.</th>
										<th>District English</th>
										<th>District Marathi</th>
										<th>Status</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
								<?php  
									$i=1; 
									foreach($arr_data as $info) 
									{ 
								?>
									<tr class="odd">
										<td class="table-plus"><?php echo $i; ?></td>
										<td><?php echo $info['district_english'] ?></td>
										<td><?php echo $info['district_marathi'] ?></td>
										<td>
											<?php 
											if($info['is_active']=='yes')
											{
											?>
											<a href="<?php echo $module_url_path ?>/active_inactive/<?php echo $info['id'].'/'.$info['is_active']; ?>"><button class="btn btn-success btn-sm">YES</button></a>
											<?php } else { ?>
											<a href="<?php echo $module_url_path ?>/active_inactive/<?php echo $info['id'].'/'.$info['is_active']; ?>"><button class="btn btn-danger btn-sm">NO</button> </a>
											<?php } ?>
										</td>
										
										<td>
											<div class="dropdown">
											<button type="button" class="btn btn-default">Action</button>
												<a
													class="btn btn-link font-24 p-0 line-height-1 no-arrow dropdown-toggle"
													href="#"
													role="button"
													data-toggle="dropdown"
												>
													<i class="dw dw-more"></i>
												</a>
												<div
													class="dropdown-menu dropdown-menu-right dropdown-menu-icon-list"
												>
													<a class="dropdown-item" href="<?php echo $module_url_path;?>/details/<?php echo $info['id'];?>" 
														><i class="dw dw-eye"></i> View</a
													>
													<a class="dropdown-item" href="<?php echo $module_url_path;?>/edit/<?php echo $info['id'];?>"
														><i class="dw dw-edit2"></i> Edit</a
													>
													<a class="dropdown-item" onclick="return confirm('Are You Sure You Want To Delete This Record?')" href="<?php echo $module_url_path;?>/delete/<?php echo $info['id']; ?>"
														><i class="dw dw-delete-3"></i> Delete</a
													>
												</div>
											</div>
										</td>
									</tr>

									<?php $i++; } ?>	

								</tbody>
							</table>
							<?php } 
							 ?>
						</div>
					</div>
					<!-- Export Datatable End -->
				</div>
</div>